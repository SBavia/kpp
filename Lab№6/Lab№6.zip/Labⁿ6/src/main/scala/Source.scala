package main.scala

object Source {

  /*1. Удалить из коллекции все повторяющиеся слова*/
  def onlyUniqueElements(list: List[Any]): List[Any] = {
    list.distinct
  }

  /*2. Проверить являются ли все числа в списке простыми*/
  def isPrime(list:List[Int]):Boolean = {
    def check(number:Int): Boolean =
      !((2 until number-1) exists (number % _ == 0))
    val m =list.foldRight(0) ((currentElement, newList ) =>
      check(currentElement) match{
        case true => newList
        case false => newList+1
      })
    if(m > 0)
      false
    else
      true
  }

  /*3. Оставить в списке лишь элементы типа String*/
  def onlyStrings(list: List[Any]): List[Any] = {
    list.filter((i: Any) => i.isInstanceOf[String])
  }
}
