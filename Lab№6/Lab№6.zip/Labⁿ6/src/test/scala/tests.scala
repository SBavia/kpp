package test.scala

import main.scala._
import org.junit.runner.RunWith
import org.scalatest.FunSuite
import org.scalatest.junit.JUnitRunner

@RunWith(classOf[JUnitRunner])
class tests extends FunSuite {

  test("empty") {
    assert(Source.onlyUniqueElements(List()) == Nil)
  }

  test("one element") {
    assert(Source.onlyUniqueElements(List("Zero")) == List("Zero"))
  }

  test("non repeated") {
    assert(Source.onlyUniqueElements(List("Zero", "One", "Two", "Three")) == List("Zero", "One", "Two", "Three"))
  }

  test("one repeated") {
    assert(Source.onlyUniqueElements(List("Zero", "One", "Two", "Three", "Zero")) == List("Zero", "One", "Two", "Three"))
  }

  test("Many repeated") {
     assert(Source.onlyUniqueElements(List("Zero", "One", "Two", "Three", "Zero", "One", "Two", "Three")) == List("Zero", "One", "Two", "Three"))
  }

  test("Not only prime elements") {
    assert(Source.isPrime(List(0, 1, 2, 3, 4, 5, 6, 7, 8, 9)) equals (false))
  }

  test("Only prime elements") {
    assert(Source.isPrime(List(0, 1, 2, 3, 5, 7, 11, 13)) equals (true))
  }

  test("No string elements") {
    assert(Source.onlyStrings(List(1,2,3)) == Nil)
  }

  test("With string elements") {
    assert(Source.onlyStrings(List(1,2,3, "abc", "sqw", "gg")) == List("abc", "sqw", "gg"))
  }
}