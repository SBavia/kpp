package main.scala

object lab7 {

  /*1. Если число делиться на 5, умножить его на 2, а если делится на 6, разделить его на 3*/
  def ifElse(numb: Int): Int = {
    if (numb % 5 == 0 && numb % 6 == 0) numb * 2 / 3
    else if (numb % 5 == 0) numb * 2
    else if (numb % 6 == 0) numb / 3
    else numb
  }

  /*2. Реализовать  функцию,  принимающую  в  качестве  параметра  число,  либо  список чисел.
  Если параметром является число, вернуть его текстовое представление.
  Если список -вернуть строку, содержащую эти числа, разделенные пробелами.*/
  def anyToString(x: Any): String = x match {
    case x: List[Int] => x.mkString(", ")
    case x: Int => x.toString
    case _ => ""
  }
}