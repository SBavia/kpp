package test.scala

import main.scala._
import org.junit.runner.RunWith
import org.scalatest.FunSuite
import org.scalatest.junit.JUnitRunner

@RunWith(classOf[JUnitRunner])
class test extends FunSuite {

  test("Is not divisible") {
    assert(lab7.ifElse(13) == 13)
  }

  test("divided by 5") {
    assert(lab7.ifElse(10) == 20)
  }

  test("divided by 6") {
    assert(lab7.ifElse(18) == 6)
  }

  test("divided by 5 and 6") {
    assert(lab7.ifElse(30) == 20)
  }

  test("parameter is a number") {
    assert(lab7.anyToString(4) == "4")
  }

  test("parameter is a list of numbers") {
    assert(lab7.anyToString(List(1,2,3)) == "1, 2, 3")
  }
}