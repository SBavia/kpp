package test.scala

import org.junit.runner.RunWith
import org.scalatest.junit.JUnitRunner
import org.scalatest.FunSuite
import org.scalatest._

import main.scala.Demo

@RunWith(classOf[JUnitRunner])
class Tests extends FunSuite {

  val array = Array[Double](10.5, 5.12, 32.1, 245.3, 24.0, 42.23, 78.6, 100.2, 28.03)

  val emptyArray = new Array[Double](0)

  test("find index of element in array with(out) tailrec") {
    assert(Demo.find(42.23, array) == 5)
    assert(Demo.findTail(78.6, array) == 6)
  }

  test("find index of not-element in array with(out) tailrec") {
    assert(Demo.find(0, array) == (-1))
    assert(Demo.findTail(0, array) == (-1))
  }

  test("find index of element in empty array with(out) tailrec") {
    assert(Demo.find(0, emptyArray) == (-1))
    assert(Demo.findTail(0, emptyArray) == (-1))
  }

  val emptylist = List[Int]()

  val list = List[Int](90, 65, 8, 13, 12, 0, 6)

  val nonelemlist = List[Int](7, 8, 13 ,14, 54)

  test("find numbers in empty list with(out) tailrec") {
    assert(Demo.findLesserThenPrev(emptylist) == Nil)
    assert(Demo.findLesserThenPrevTailRec(emptylist) == Nil)
  }

  test("find numbers in list with(out) tailrec") {
    assert(Demo.findLesserThenPrev(list) == List(8,13,0,6))
    assert(Demo.findLesserThenPrevTailRec(list) == List(8,13,0,6))
  }

  test("find non-numbers in list with(out) tailrec") {
    assert(Demo.findLesserThenPrev(nonelemlist) == Nil)
    assert(Demo.findLesserThenPrevTailRec(nonelemlist) == Nil)
  }
}

/*class Tests extends FlatSpec with Matchers {
  val array = Array[Double](10.5, 5.12, 32.1, 245.3, 24.0, 42.23, 78.6, 100.2, 28.03)

  it should "find index of element in array" in {
    Demo.find(42.23, array) should be(5)
  }

  it should "find index of element in array by tailrec" in {
    Demo.findTail(78.6, array) should be(6)
  }

  it should "find index of not-element in array" in {
    Demo.find(0, array) should be(-1)
  }

  it should "find index of not-element in array by tailrec" in {
    Demo.findTail(25, array) should be(-1)
  }

  val emptyArray = new Array[Double](0)

  it should "find index of element in empty array" in {
    Demo.find(42.23, emptyArray) should be(-1)
  }

  it should "find index of element in empty array by tailrec" in {
    Demo.findTail(5, emptyArray) should be(-1)
  }

  val emptylist = List[Int]()

  it should "find numbers in empty list" in {
    Demo.findLesserThenPrev(emptylist) should be (Nil)
  }

  it should "find numbers in empty list by tailrec" in {
    Demo.findLesserThenPrevTailRec(emptylist) should be (Nil)
  }

  val list = List[Int](90, 65, 8, 13, 12, 0, 6)

  it should "find numbers in list" in {
    Demo.findLesserThenPrev(list) should be (List(8,13,0,6))
  }

  it should "find numbers in list by tailrec" in {
    Demo.findLesserThenPrevTailRec(list) should be (List(8,13,0,6))
  }

  val nonelemlist = List[Int](7, 8, 13 ,14, 54)

  it should "find non-numbers in list" in {
    Demo.findLesserThenPrev(nonelemlist) should be (Nil)
  }

  it should "find non-numbers in list by tailrec" in {
    Demo.findLesserThenPrevTailRec(nonelemlist) should be (Nil)
  }
}*/