package main.scala

import scala.annotation.tailrec

object Demo {

  def findTail(number: Double, arr: Array[Double]) : Int = {
    @tailrec
    def compare(number: Double, arr: Array[Double], size: Int) : Int = {
      if (size < 0)
        -1
      else if (number == arr(size))
        size
      else
        compare(number, arr, size - 1)
    }
    compare(number, arr, arr.length - 1)
  }

  def find(number: Double, arr: Array[Double]) : Int = {
    def compare(number: Double, arr: Array[Double], size: Int): Int = {
      if (size == arr.length)
        -(arr.length + 1)
      else if (number == arr(size))
        0
      else
        1 + compare(number, arr, size + 1)
    }
    compare(number, arr , 0)
  }

  def findLesserThenPrevTailRec(list : List[Int]) : List[Int] = {
    @tailrec
    def start(result : List[Int], number : Int) : List[Int] = {
      if (list.length <= number)
        result
      else if (list(number) < Math.abs(list(number - 2) - list(number - 1)))
        start(result :+ list(number), number + 1)
      else
        start(result, number + 1)
    }
    if (list.length == 0)
      List[Int]()
    else
      start(Nil, 2)
  }

  def findLesserThenPrev(list : List[Int]) : List[Int] = {
    def start(number : Int) : List[Int] = {
      if(list.length <= number)
        Nil
      else if (list(number) < Math.abs(list(number - 2) - list(number - 1)))
        list(number) :: start(number + 1)
      else
        start(number + 1)
    }
    if (list.length == 0)
      List[Int]()
    else
      start(2)
  }
}